package com.jsp.FarmerFriend_Team05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmerFriendTeam05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
