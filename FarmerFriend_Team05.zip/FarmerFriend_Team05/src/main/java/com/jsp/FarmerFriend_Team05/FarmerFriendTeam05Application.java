package com.jsp.FarmerFriend_Team05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmerFriendTeam05Application {

	public static void main(String[] args) {
		SpringApplication.run(FarmerFriendTeam05Application.class, args);
	}

}
