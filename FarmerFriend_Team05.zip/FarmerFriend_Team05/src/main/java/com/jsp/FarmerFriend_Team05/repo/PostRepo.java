package com.jsp.FarmerFriend_Team05.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.FarmerFriend_Team05.entity.Post;

public interface PostRepo extends JpaRepository<Post, String> {

}
